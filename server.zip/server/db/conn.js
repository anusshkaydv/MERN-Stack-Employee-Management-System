const { MongoClient } = require("mongodb");
require("dotenv").config(); // ✅ Load environment variables from .env

const uri = process.env.ATLAS_URI;

const client = new MongoClient(uri, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

let _db;

module.exports = {
  connectToMongoDB: async function (callback) {
    try {
      await client.connect();
      _db = client.db("employees"); // ✅ Name of your DB (you can change this)
      console.log("✅ Successfully connected to MongoDB.");
      return callback(null);
    } catch (error) {
      console.error("❌ MongoDB connection error:", error);
      return callback(error);
    }
  },

  getDb: function () {
    return _db;
  },
};
