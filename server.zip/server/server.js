const express = require("express");
const cors = require("cors");
const dbo = require("./db/conn");
require("dotenv").config();

const app = express();
const port = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// Routes
app.use(require("./routes/record"));

// Basic route for testing
app.get("/", (req, res) => {
  res.send("✅ App is running");
});

// Connect to MongoDB, then start the server
dbo.connectToMongoDB((err) => {
  if (err) {
    console.error("❌ Failed to connect to MongoDB:", err);
    process.exit(1); // Exit with error
  }

  app.listen(port, () => {
    console.log(`🚀 Server is running on port: ${port}`);
  });
});
